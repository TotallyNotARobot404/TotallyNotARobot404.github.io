// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // get lengths now instead of calling the function every time.
    // this would have most likely been inlined by the compiler, but design for perfomance.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i)
    { 
        //based on https://www.programmingalgorithms.com/algorithm/xor-encryption/cpp/ with it's incription method
        //while data = source in this case 
        //output[i] = source[i];
        output[i] = source[i] ^ key[i % key_length];
    }

    // our output length must equal our source length
    assert(output.length() == source_length);

    // return the transformed string
    return output;
}

//Caesar Encyrption
std::string encrypt(std::string text, int s)
{
    //initial variable
    std::string result = "";

    // traverse text
    for (int i = 0; i < text.length(); i++)
    {
        //encrypt each one
        //keep space
        if (isspace(text[i]))
            result += " ";

        // encrypt uppercase letters
        else if (isupper(text[i]))
            result += char(int(text[i] + s - 65) % 26 + 65);

        // encrypt lowercase letters
        else
            result += char(int(text[i] + s - 97) % 26 + 97);
    }

    // Return the resulting string
    return result;
}
//Caesar Decryption
std::string decrypt(std::string text, int s)
{
    //set initial variables
    std::string result = "";
    //decrypt int
    s = 26 - s;

    // traverse text
    for (int i = 0; i < text.length(); i++)
    {
        //encrypt each one
        //keep space
        if (isspace(text[i]))
            result += " ";

        // decrypt Uppercase letters
        else if (isupper(text[i]))
            result += char(int(text[i] + s - 65) % 26 + 65);

        // decrypt Lowercase letters
        else
            result += char(int(text[i] + s - 97) % 26 + 97);
    }

    // return the resulting string
    return result;
}

//read from file
std::string read_file(const std::string& filename)
{
    //set up starting one
    std::string file_text = "John Q. Smith\nThis is my test string";

    //set up ifstream
    std::ifstream t(filename);

    t.seekg(0, std::ios::end);
    //placing file_text as the used string
    file_text.reserve(t.tellg());
    t.seekg(0, std::ios::beg);

    //assigning it to system
    file_text.assign((std::istreambuf_iterator<char>(t)),
        std::istreambuf_iterator<char>());

    //returning new file text
    return file_text;
}

//get the student name from file
std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // find the first newline
    size_t pos = string_data.find('\n');
    // did we find a newline
    if (pos != std::string::npos)
    { // we did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
    }
    //return name
    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    // get the date time
    auto t = std::time(nullptr);
    struct tm buf;
    auto tm = localtime_s(&buf, &t);

    //save to the file
    std::ofstream saveToFile;
    saveToFile.open(filename);
    saveToFile << student_name << "\n";
    saveToFile << std::put_time(&buf, "%Y-%m-%d") << "\n";
    saveToFile << key << "\n";
    saveToFile << data << "\n";
    saveToFile.close();
}

//save to the file with Caesar encryption
void save_data_file_C(const std::string& filename, const std::string& student_name, const int s, const std::string& data)
{
    // get the date time
    auto t = std::time(nullptr);
    struct tm buf;
    auto tm = localtime_s(&buf, &t);

    //help from https://www.cplusplus.com/doc/tutorial/files/
    std::ofstream saveToFile;
    saveToFile.open(filename);
    saveToFile << student_name << "\n";
    saveToFile << std::put_time(&buf, "%Y-%m-%d") << "\n";
    saveToFile << s << "\n";
    saveToFile << data << "\n";
    saveToFile.close();
}

//sets up the Caesar encrytionv on CL
std::string caesar_text(std::string text, int s)
{
    std::cout << "\nText : " << text;
    std::cout << "\nShift: " << s;
    std::cout << "\nCipher: " << encrypt(text, s);
    std::cout << "\nDecrypted: " << decrypt(encrypt(text, s), s);
    return encrypt(text, s);
}

//sets up the Caesar encryption on file
void caesar_file(const std::string source_string, const std::string file_name, const std::string encrypted_file_name, const std::string decrypted_file_name)
{
    // get the student name from the data file
    const std::string student_name = get_student_name(source_string);
    //get the key initialized
    int s;

    //ask for the integer to create
    std::cout << "Input an integer between 1 - 26" << std::endl;
    std::cin >> std::ws;
    std::cin >> s;
    //ensures correct action
    while ((s < 1) || (s > 26))
    {
        std::cout << "Input an integer between 1 - 26" << std::endl;
        std::cin >> std::ws;
        std::cin >> s;
    }
    // encrypt sourceString with key
    const std::string encrypted_string = encrypt(source_string, s);

    // save encrypted_string to file
    save_data_file_C(encrypted_file_name, student_name, s, encrypted_string);

    // decrypt encryptedString with key
    const std::string decrypted_string = decrypt(encrypted_string, s);

    // save decrypted_string to file
    save_data_file_C(decrypted_file_name, student_name, s, decrypted_string);

    //show info on what happened in filesystem
    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;
}

//pulls out info for the XOR CL info
std::string xor_text(std::string text, const std::string& key)
{
    std::cout << "Text : " << text;
    std::cout << "\nKey: " << key << std::endl;
    std::cout << "\nCipher: " << encrypt_decrypt(text, key);
    std::cout << "\nDecrypted: " << encrypt_decrypt(encrypt_decrypt(text, key), key);
    return encrypt_decrypt(text, key);
}

//sets up the XOR encryption on file
void xor_file(const std::string source_string, const std::string file_name, const std::string encrypted_file_name, const std::string decrypted_file_name)
{
    // get the student name from the data file
    const std::string student_name = get_student_name(source_string);

    //set up the key
    std::string key;
    std::cout << "Input a key" << std::endl;
    std::cin >> std::ws;
    std::getline(std::cin, key);

    // encrypt sourceString with key
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // save encrypted_string to file
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // decrypt encryptedString with key
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // save decrypted_string to file
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    //shows what occurred
    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;
}

//main where actions occur
int main()
{
    std::cout << "Encyption Decryption Test!" << std::endl;

    //set up intro variables
    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt";
    const std::string source_string = read_file(file_name);

    std::string selection = "";

    //selection for encryption
    //while not exit will operate
    while (selection != "exit")
    {
        //set up insert or run queries
        std::cout << "\nSelect an option of:" << std::endl;
        std::cout << "\nCaesar Encyrption, XOR Encryption, Both or Ending Program" << std::endl;
        std::cout << "\nUsing 'caesar', 'xor', 'both' or 'exit'" << std::endl;
        std::cin >> selection;

        if (selection == "caesar")
        {
            //text or file option
            std::cout << "Select an option of:" << std::endl;
            std::cout << "\nInputting text into system or through a file" << std::endl;
            std::cout << "\nUsing 'text' or 'file'" << std::endl;
            std::cin >> selection;

            if (selection == "text")
            {
                std::string text;
                int s;
                //Caesar encyption through text
                //get string and then get key
                std::cout << "Input a string" << std::endl;
                std::cin >> std::ws;
                std::getline(std::cin, text);
                std::cout << "Input an integer between 1 - 26" << std::endl;
                std::cin >> std::ws;
                std::cin >> s;
                //test to make sure within confines of encyrption
                while ((s < 1) || (s > 26))
                {
                    std::cout << "Input an integer between 1 - 26" << std::endl;
                    std::cin >> std::ws;
                    std::cin >> s;
                }
                caesar_text(text, s);
            }
            else if (selection == "file")
            {
                //calls file collection
                caesar_file(source_string, file_name, encrypted_file_name, decrypted_file_name);
            }
            
        }
        else if (selection == "xor")
        {
            //selection of text or file
            std::cout << "\nSelect an option of:" << std::endl;
            std::cout << "\nInputting text into system or through a file" << std::endl;
            std::cout << "\nUsing 'text' or 'file'" << std::endl;
            std::cin >> selection;

            if (selection == "text")
            {
                //initial variables
                std::string text;
                std::string key;
                //xor encyption through text
                std::cout << "Input a string" << std::endl;
                std::cin >> std::ws;
                std::getline(std::cin, text);
                //how to cipher it
                std::cout << "Input a key" << std::endl;
                std::cin >> std::ws;
                std::getline(std::cin, key);
                xor_text(text, key);
            }
            else if (selection == "file")
            {
                //call to bring into the file system
                xor_file(source_string, file_name, encrypted_file_name, decrypted_file_name);
            }
        }
        else if (selection == "both")
        {
            //combo of them both select text or file first
            std::cout << "\nSelect an option of:" << std::endl;
            std::cout << "\nInputting text into system or through a file" << std::endl;
            std::cout << "\nUsing 'text' or 'file'" << std::endl;
            std::cin >> selection;

            if (selection == "text")
            {
                //when text select which to do first
                std::cout << "\nSelect an option of:" << std::endl;
                std::cout << "\nWhich to do first" << std::endl;
                std::cout << "\nUsing 'xor' or 'caesar'" << std::endl;
                std::cin >> selection;

                if (selection == "xor")
                {
                    std::string text;
                    std::string key;
                    int s;
                    //xor encyption through text
                    std::cout << "\nInput a string" << std::endl;
                    std::cin >> std::ws;
                    std::getline(std::cin, text);
                    //key for xor
                    std::cout << "\nInput a key" << std::endl;
                    std::cin >> std::ws;
                    std::getline(std::cin, key);
                    std::string part = xor_text(text, key);

                    //then the variable and ensuring proper placement
                    std::cout << "\nInput an integer between 1 - 26" << std::endl;
                    std::cin >> std::ws;
                    std::cin >> s;
                    while ((s < 1) || (s > 26))
                    {
                        std::cout << "\nInput an integer between 1 - 26" << std::endl;
                        std::cin >> std::ws;
                        std::cin >> s;
                    }
                    caesar_text(part, s);

                }
                if (selection == "caesar")
                {
                    //initial variables
                    std::string text;
                    std::string key;
                    int s;
                    //Caesar encyption through text
                    std::cout << "\nInput a string" << std::endl;
                    std::cin >> std::ws;
                    std::getline(std::cin, text);
                    std::cout << "\nInput an integer between 1 - 26" << std::endl;
                    std::cin >> std::ws;
                    std::cin >> s;
                    //ensure proper 1 - 26
                    while ((s < 1) || (s > 26))
                    {
                        std::cout << "\nInput an integer between 1 - 26" << std::endl;
                        std::cin >> std::ws;
                        std::cin >> s;
                    }
                    std::string part = caesar_text(text, s);
                    //then add the key to use to cipher it
                    std::cout << "\nInput a key" << std::endl;
                    std::cin >> std::ws;
                    std::getline(std::cin, key);
                    xor_text(part, key);
                }

            }
            //now for file
            else if (selection == "file")
            {
                //choose which to start with first
                std::cout << "\nSelect an option of:" << std::endl;
                std::cout << "\nWhich to do first" << std::endl;
                std::cout << "\nUsing 'xor' or 'caesar'" << std::endl;
                std::cin >> selection;
                if (selection == "xor")
                {
                    std::string key;
                    std::cout << "\nInput a key" << std::endl;
                    std::cin >> std::ws;
                    std::getline(std::cin, key);
                    // encrypt sourceString with key
                    std::string encrypted_string = encrypt_decrypt(source_string, key);
                    // then place encrypted string into ceasar
                    caesar_file(encrypted_string, file_name, encrypted_file_name, decrypted_file_name);
                    
                }
                if (selection == "caesar")
                {
                    //initialize variable here
                    int s;
                    std::cout << "Input an integer between 1 - 26" << std::endl;
                    std::cin >> std::ws;
                    std::cin >> s;
                    //while loop for proper encyrption
                    while ((s < 1) || (s > 26))
                    {
                        std::cout << "Input an integer between 1 - 26" << std::endl;
                        std::cin >> std::ws;
                        std::cin >> s;
                    }
                    //place it into an encyrpted string
                    std::string encrypted_string = encrypt(source_string, s);
                    //use that for then calling XOR file
                    xor_file(encrypted_string, file_name, encrypted_file_name, decrypted_file_name);
                }
            }
        }
        //escape method
        else if (selection == "exit")
        {
        return(0);
        }
    }

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
